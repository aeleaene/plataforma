import React from 'react';

import ContenidoAdminDashboard from '../ContenidoAdminDashboard/ContenidoAdminDashboard'

const AdminDashboard = (props) => {
    return(
        <ContenidoAdminDashboard />
    )
}

export default AdminDashboard;