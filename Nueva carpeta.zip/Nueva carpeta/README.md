# README #

Proyecto principal para nueva plataforma de Sabueso System Tracking

### Este repositorio es para subir y controlar cambios realizados al codigo principal de este proyecto ###

* Escrito en ```React```
* ```Traccar API```

### ¿Como iniciar? ###

* Clonar el repositorio: 
```
git clone https://github.com/aeleaene/plataforma.git
```
* Instalar las dependencias 
```
npm install
```
* Iniciar el proyecto 
``` 
cd plataforma
npm start
```
### El contenido de este repositorio es propiedad de  ###
```Sabueso System Tracking```  &copy;
